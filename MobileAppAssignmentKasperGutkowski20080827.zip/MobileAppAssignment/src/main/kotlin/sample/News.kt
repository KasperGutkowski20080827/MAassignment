package sample

data class News (var newsId: Int = 0,
                 var newsTitle: String = "",
                 var newsDescription: String = "",
                 var newsAuthor: String = ""){

}